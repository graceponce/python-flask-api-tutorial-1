# `03.2` Check for live URL 

¡Al parecer tu API se está ejecutando!

Puedes verificarlo haciendo clic en la URL que se ve en la línea de comandos una vez que Flask haya comenzado a ejecutarse así:

![Check Flask Live](../../assets/live-api.gif?raw=true)

Una vez que hayas abierto exitosamente to API live, debería decir `Not Found`, así:

![Not found API](../../assets/not-found.png?raw=true)

Dice `Not found` en este momento porque no hemos añadido ningún enpoint aún ¡Ahora tenemos que comenzar a añadir endpoints!

