# `02.1` Install Flask

Ahora tenemos que instalar la dependencia de nuestro primer paquete para este proyecto: [Flask](https://flask.palletsprojects.com/en/1.1.x/).

## 📝 Instrucciones:

1. Ejecuta el siguiente comando en tu terminal para instalar el paquete de Flask:

```bash
$ pipenv install flask
```

## Resultado esperado:

![Expected console ouput](../../assets/install-flask.png?raw=true)

Prueba estos pasos y dale clic a  `next →` para continuar.
