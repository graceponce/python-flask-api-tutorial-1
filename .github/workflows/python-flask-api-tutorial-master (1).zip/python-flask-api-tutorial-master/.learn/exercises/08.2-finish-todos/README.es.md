# `08.2` Finish delete todo

## 📝 Instrucciones:

Termina el `DELETE /todos/<int:position>` completando los siguientes pasos:

1. Recibe la posición que el cliente desea eliminar como primer parámetro de la función del endpoint `delete_todo`.

2. Elimina la tarea (task) de la lista de `todos`. Puedes usar cualquier método de Python que permita eliminar items de una lista por posición.

3. Retorna el jsonify de la lista de `todos` actualizado. 
