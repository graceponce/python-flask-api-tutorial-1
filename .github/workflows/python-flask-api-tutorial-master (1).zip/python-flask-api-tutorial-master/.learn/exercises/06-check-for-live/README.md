# `06` Check the API

Now you can check your endpoint live in the browser.  It should be returning the list of todos in JSON format like this:

![check live todos](../../assets/return_todos.gif?raw=true)
