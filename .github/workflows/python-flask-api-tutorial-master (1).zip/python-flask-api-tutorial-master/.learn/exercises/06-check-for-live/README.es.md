# `06` Check the API

Ahora puedes verificar tu endpoint live y debería retornar la lista de todos así:

![check live todos](../../assets/return_todos.gif?raw=true)