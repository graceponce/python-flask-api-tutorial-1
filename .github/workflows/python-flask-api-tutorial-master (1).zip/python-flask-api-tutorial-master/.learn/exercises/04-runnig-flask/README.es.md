# `04` Demo your API!!

¡Felicitaciones! Tu primer endpoint está LIVE ahora! Probablemente en:

```txt
GET https://localhost:3245/todos
```

Verifica la endpoint de tu API ingresando esa URL en tu navegador. Deberías ver un mensaje `Hello!` como este:

![Demo your API](../../assets/check-live.gif?raw=true)
